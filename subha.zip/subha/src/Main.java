import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        double fahrenheit ,celcius;
        Scanner input = new Scanner(System.in);
        //celcius to fehrenjeit \u2103 degree Celcius symbol
        System.out.println("Input temperature(\u2103):");
        celcius = input.nextDouble();
        System.out.println(celcius * 1.8 + 32 + "\u2109 \n");

        //fehrenhit to cdelcius \u2109 degree symbol
        System.out.println("Input temperature (\u2109");
        fahrenheit = input.nextDouble();
        System.out.println((fahrenheit -32) /1.8 + "\u2109");

    }

}